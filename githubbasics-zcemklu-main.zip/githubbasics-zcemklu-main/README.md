EMG Scenario 4 Group 11

This repo aims to collect all code files for testing, troubleshooting and running used in the making of the EMG Regaining Control scenario.

Folder description:
1. emg-combined - codes for all movement functionalities
2. emg-movements - codes for individual movement
3. emg-troubleshooting - codes for testing & troubleshooting

How to use code files:
1. Download code
2. Open in Arduino IDE
3. Upload to Arduino Leonardo board
